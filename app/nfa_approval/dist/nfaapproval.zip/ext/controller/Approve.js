sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Approve:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Approve.js.map