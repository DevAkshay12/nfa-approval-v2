sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Reject:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Reject.js.map